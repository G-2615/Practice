package com.cts.seller.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.seller.entities.Items;

@Repository
public interface ItemRepository extends JpaRepository<Items, Integer> {

	
	
	@Query(value = "SELECT * FROM item_info WHERE seller_id_seller_id = :seller_Id", nativeQuery = true)
	public List<Items> findBySeller_Id(@Param("seller_Id")Integer seller_Id);
	
	 @Query(value="from Items where item_Name like %:itemname%")                                      
	 public List<Items>finditem(@Param("itemname")String itemName);
	 

}
