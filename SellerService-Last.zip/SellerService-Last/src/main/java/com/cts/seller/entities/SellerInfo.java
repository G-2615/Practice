package com.cts.seller.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class SellerInfo {

	@Id
	@GeneratedValue
	private int seller_Id;
	private String seller_Username;
	private String seller_Password;
	private String seller_Companyname;
	private String seller_GSTIN;
	private String seller_Companydesc;
	private String seller_Postaladdress;
	private String seller_Emailid;
	private long seller_contactnum;
	private String seller_Website;
	public int getSeller_Id() {
		return seller_Id;
	}
	public void setSeller_Id(int seller_Id) {
		this.seller_Id = seller_Id;
	}
	public String getSeller_Username() {
		return seller_Username;
	}
	public void setSeller_Username(String seller_Username) {
		this.seller_Username = seller_Username;
	}
	public String getSeller_Password() {
		return seller_Password;
	}
	public void setSeller_Password(String seller_Password) {
		this.seller_Password = seller_Password;
	}
	public String getSeller_Companyname() {
		return seller_Companyname;
	}
	public void setSeller_Companyname(String seller_Companyname) {
		this.seller_Companyname = seller_Companyname;
	}
	public String getSeller_GSTIN() {
		return seller_GSTIN;
	}
	public void setSeller_GSTIN(String seller_GSTIN) {
		seller_GSTIN = seller_GSTIN;
	}
	public String getSeller_Companydesc() {
		return seller_Companydesc;
	}
	public void setSeller_Companydesc(String seller_Companydesc) {
		this.seller_Companydesc = seller_Companydesc;
	}
	public String getSeller_Postaladdress() {
		return seller_Postaladdress;
	}
	public void setSeller_Postaladdress(String seller_Postaladdress) {
		this.seller_Postaladdress = seller_Postaladdress;
	}
	public String getSeller_Emailid() {
		return seller_Emailid;
	}
	public void setSeller_Emailid(String seller_Emailid) {
		this.seller_Emailid = seller_Emailid;
	}
	public long getSeller_contactnum() {
		return seller_contactnum;
	}
	public void setSeller_contactnum(long seller_contactnum) {
		this.seller_contactnum = seller_contactnum;
	}
	public String getSeller_Website() {
		return seller_Website;
	}
	public void setSeller_Website(String seller_Website) {
		this.seller_Website = seller_Website;
	}
	public SellerInfo(int seller_Id, String seller_Username, String seller_Password, String seller_Companyname,
			String seller_GSTIN, String seller_Companydesc, String seller_Postaladdress, String seller_Emailid,
			long seller_contactnum, String seller_Website) {
		super();
		this.seller_Id = seller_Id;
		this.seller_Username = seller_Username;
		this.seller_Password = seller_Password;
		this.seller_Companyname = seller_Companyname;
		this.seller_GSTIN = seller_GSTIN;
		this.seller_Companydesc = seller_Companydesc;
		this.seller_Postaladdress = seller_Postaladdress;
		this.seller_Emailid = seller_Emailid;
		this.seller_contactnum = seller_contactnum;
		this.seller_Website = seller_Website;
	}
	
	public SellerInfo() {
		super();
		
	}
	@Override
	public String toString() {
		return "SellerInfo [seller_Id=" + seller_Id + ", seller_Username=" + seller_Username + ", seller_Password="
				+ seller_Password + ", seller_Companyname=" + seller_Companyname + ", seller_GSTIN=" + seller_GSTIN
				+ ", seller_Companydesc=" + seller_Companydesc + ", seller_Postaladdress=" + seller_Postaladdress
				+ ", seller_Emailid=" + seller_Emailid + ", seller_contactnum=" + seller_contactnum
				+ ", seller_Website=" + seller_Website + "]";
	}
	
	
	
	
	
	
	
	
}
