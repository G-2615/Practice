package com.cts.seller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SellerServiceLastApplication {

	public static void main(String[] args) {
		SpringApplication.run(SellerServiceLastApplication.class, args);
	}

}
