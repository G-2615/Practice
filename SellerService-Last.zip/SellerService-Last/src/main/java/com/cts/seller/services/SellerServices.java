package com.cts.seller.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.seller.Repository.SellerRepository;
import com.cts.seller.entities.SellerInfo;

@Service
public class SellerServices {
	
	@Autowired
	private SellerRepository sellerRepository;

	public SellerInfo addSeller(SellerInfo seller) {
		// TODO Auto-generated method stub
		return sellerRepository.save(seller);
	}

}
 