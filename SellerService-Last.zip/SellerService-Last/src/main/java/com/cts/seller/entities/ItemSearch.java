package com.cts.seller.entities;

public class ItemSearch {
  private String itemname;
  
  public ItemSearch() {
	  
  }

public ItemSearch(String itemname) {
	super();
	this.itemname = itemname;
}

public String getItemname() {
	return itemname;
}

public void setItemname(String itemname) {
	this.itemname = itemname;
}

@Override
public String toString() {
	return "ItemSearch [itemname=" + itemname + "]";
}
  
  
}
