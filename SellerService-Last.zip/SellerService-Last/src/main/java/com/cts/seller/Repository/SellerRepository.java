package com.cts.seller.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.seller.entities.SellerInfo;

@Repository
public interface SellerRepository extends JpaRepository<SellerInfo, Integer> {

}
