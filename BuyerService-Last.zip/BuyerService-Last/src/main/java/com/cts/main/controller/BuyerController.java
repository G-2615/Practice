package com.cts.main.controller;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.main.entities.CartItems;
import com.cts.main.entities.UserInfo;
import com.cts.main.services.BuyerServices;
import com.cts.main.services.CartServices;

@CrossOrigin(origins="*")
@RestController
public class BuyerController {
	
	@Autowired
	private BuyerServices buyerServices;
	
	@Autowired
	private CartServices cartServices;
	
	
	@RequestMapping(value="adduser",method=RequestMethod.POST, produces="application/json")
	
	public UserInfo add(@RequestBody UserInfo user ) {
		System.out.println(user);
		UserInfo userInfo = buyerServices.adduser(user);
		return userInfo;
		
	}
	
	
	

}
