package com.cts.main.controller;

import java.util.List;
import java.util.Optional;

import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.main.entities.CartItems;
import com.cts.main.entities.TransactionHistory;
import com.cts.main.services.CartServices;
import com.cts.main.services.PurchaseServices;
import com.cts.main.services.TransactionServices;
@CrossOrigin(origins="*")
@RestController
public class CartController {
	
	
	
	@Autowired
	private CartServices cartServices;
	
	@Autowired
	private TransactionServices transService;
	
    @Autowired
	private PurchaseServices purService;
	
    @RequestMapping(value="Buyer/{buyer_Id}/addcartitem",method=RequestMethod.POST, produces="application/json")
	
	public CartItems addCart(@PathVariable(value="buyer_Id") Integer buyer_Id,@RequestBody CartItems cartItems) {
		System.out.println(cartItems);
    	Optional<CartItems>saveItem=cartServices.addtoCart(cartItems,buyer_Id);
		return saveItem.get();
		
	}
    
   @RequestMapping(value="/{buyer_Id}/allitems",method=RequestMethod.GET, produces="application/json")
    public List<CartItems>getall(@PathVariable(value="buyer_Id") Integer buyer_Id){
    	
    	List<CartItems>getallItems=cartServices.getallCartItems(buyer_Id);
    	return getallItems;
    }
   
   

	/*
	 * @RequestMapping(value="/{buyer_Id}/allitems",method=RequestMethod.PUT,
	 * produces="application/json") Public CartItems
	 * updateCart(@PathVariable(value="cart_Id") Integer cart_Id, @RequestBody
	 * CartItems cartItems) {
	 * 
	 * return cartServices.updateCart(cartItems,cart_Id); }
	 */
   @RequestMapping(value="/{cart_Id}/update",method=RequestMethod.PUT, produces="application/json")
   public CartItems updateCart(@PathVariable(value="cart_Id") Integer cart_Id, @RequestBody CartItems cartItems) {
	  
	  return cartServices.updateCart(cartItems,cart_Id);
	  }
   
   @RequestMapping(value="/{cart_Id}/deletebyID",method=RequestMethod.DELETE, produces="application/json")
   
   public String deleteItems(@PathVariable(value="cart_Id") Integer cart_Id ) {
   
    String s = cartServices.deleteID(cart_Id);
   
    return s;
   }
   
@RequestMapping(value="/{buyer_Id}/deleteAll",method=RequestMethod.DELETE, produces="application/json")
   
   public String emptyCart(@PathVariable(value="buyer_Id") Integer buyer_Id ) {
	
	String ss= cartServices.empty(buyer_Id);
	
	return ss;
}

@RequestMapping(value="checkout/{buyer_Id}",method=RequestMethod.POST, produces="application/json")
 	public String checkOut(@RequestBody TransactionHistory trans,@PathVariable("buyer_Id") Integer buyer_Id ) {
			
	return cartServices.checkout(trans,buyer_Id);
	
}
   
    


}
