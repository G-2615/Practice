package com.cts.main.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.main.entities.TransactionHistory;
import com.cts.main.repository.BuyerRepository;
import com.cts.main.repository.PurchaseRepository;
import com.cts.main.repository.TransactionRepository;

@Service
public class TransactionServices {
	
	@Autowired
	private BuyerRepository buyerRepo;
	
	@Autowired
	private PurchaseRepository purRepository;
	
	@Autowired
	private TransactionRepository transRepository;
	
	public Optional<TransactionHistory> transactionAdding(TransactionHistory transactionhistory, Integer buyer_Id){
		return buyerRepo.findById(buyer_Id).map(user -> {transactionhistory.setUser(user);
		
		return transRepository.save(transactionhistory);
		
		});
	}
	
	
	
}
