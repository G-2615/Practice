package com.cts.main.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class CartItems {
	
	@Id
	@GeneratedValue
	private int cart_Id;
	private int item_Id;
	private int quantity;
	
	@ManyToOne
	private UserInfo user;

	public int getCart_Id() {
		return cart_Id;
	}

	public void setCart_Id(int cart_Id) {
		this.cart_Id = cart_Id;
	}

	public int getItem_Id() {
		return item_Id;
	}

	public void setItem_Id(int item_Id) {
		this.item_Id = item_Id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public UserInfo getUser() {
		return user;
	}

	public void setUser(UserInfo user) {
		this.user = user;
	}

	public CartItems(int cart_Id, int item_Id, int quantity, UserInfo user) {
		super();
		this.cart_Id = cart_Id;
		this.item_Id = item_Id;
		this.quantity = quantity;
		this.user = user;
	}

	public CartItems() {
		super();
	}

	@Override
	public String toString() {
		return "CartItems [cart_Id=" + cart_Id + ", item_Id=" + item_Id + ", quantity=" + quantity + ", user=" + user
				+ "]";
	}
	
	

}
