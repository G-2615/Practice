package com.cts.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.main.entities.CartItems;

public interface CartRepository extends JpaRepository<CartItems, Integer> {

}
