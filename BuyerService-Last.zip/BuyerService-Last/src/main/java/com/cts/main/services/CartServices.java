package com.cts.main.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.main.entities.CartItems;
import com.cts.main.repository.BuyerRepository;
import com.cts.main.repository.CartRepository;

@Service
public class CartServices {
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;

	public Optional<CartItems> addtoCart(CartItems cartItems,Integer buyer_Id) {
		
		return buyerRepository.findById(buyer_Id).map(buyer -> {
            cartItems.setUser(buyer);
            return cartRepository.save(cartItems);
        });
				
		}

	public List<CartItems> getallCartItems(Integer buyer_Id) {
		// TODO Auto-generated method stub
		List<CartItems>getallItems=cartRepository.findAllBybuyer(buyer_Id);
		return getallItems;
	}
	
	public CartItems updateCart(CartItems cartItems, Integer cart_Id) {
		Optional<CartItems>cartItem= cartRepository.findById(cart_Id);
		//return cartRepository.save(cartItem);
		if(cartItem!=null) {
			CartItems cart=cartItem.get();
			cart.setQuantity(cartItems.getQuantity());
			return cartRepository.save(cart);
			
		}
		return null;
		
	
}
}

