package com.cts.main.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.main.entities.CartItems;
import com.cts.main.repository.BuyerRepository;
import com.cts.main.repository.CartRepository;

@Service
public class CartServices {
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;

	public Optional<CartItems> addtoCart(CartItems cartItems,Integer buyer_Id) {
		
		return buyerRepository.findById(buyer_Id).map(buyer -> {
            cartItems.setUser(buyer);
            return cartRepository.save(cartItems);
        });
				
		}
	
}

