package com.cts.main.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.main.entities.UserInfo;
import com.cts.main.repository.BuyerRepository;

@Service
public class BuyerServices {
	
	@Autowired
	private BuyerRepository buyerRepository;

	public UserInfo adduser(UserInfo user) {
		// TODO Auto-generated method stub
		return buyerRepository.save(user);
	}

}
