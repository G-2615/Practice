package com.example.demo.Repositry;

public interface BuyerRepos {

}
