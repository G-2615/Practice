package com.example.demo.Entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Transactions {
	@Id
	private int transaction_id;
	/*@ManyToOne//user_id
	private Buyer user;*/
	//seller_id
	private String transaction_type;//(Eg. debit or credit)
	@Temporal(TemporalType.TIMESTAMP)
	private Date date_time;
	public Transactions()
	{
		System.out.println("Transation Object has been created");
	}

	
	public Transactions(int transaction_id, String transaction_type, Date date_time)
	{
		this.transaction_id = transaction_id;
		//this.user = user;
		this.transaction_type = transaction_type;
		this.date_time = date_time;
	}


	
	


	@Override
	public String toString() {
		return "Transactions [transaction_id=" + transaction_id + ", transaction_type=" + transaction_type
				+ ", date_time=" + date_time + "]";
	}


	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	

	public Date getDate_time() {
		return date_time;
	}

	public void setDate_time(Date date_time) {
		this.date_time = date_time;
	}
	
	

}

