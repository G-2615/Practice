import { Component, OnInit, Input } from '@angular/core';
import { infobuyer } from '../buyerinfo';
import {BuyerService} from '../buyer.service';
@Component({
  selector: 'app-buyersignup',
  templateUrl: './buyersignup.component.html',
  styleUrls: ['./buyersignup.component.css']
})
export class BuyersignupComponent implements OnInit {
  buyer_Name:string;
	buyer_Email:string;
  buyer_Mobile:number;
	buyer_password:string;
	buyer_add1:string;
	buyer_add2:string;
  @Input() info : infobuyer  = new infobuyer();

  constructor(private dataService : BuyerService) { }

  ngOnInit(): void {

    

    }
    buyersign(){
      this.info.buyer_Name = this.buyer_Name;
      this.info.buyer_Email = this.buyer_Email;
      this.info.buyer_Mobile = this.buyer_Mobile;
      this.info.buyer_password = this.buyer_password;
      this.info.buyer_add1 = this.buyer_add1;
      this.info.buyer_add2 = this.buyer_add2;

      this.dataService.buyersign(this.info).subscribe(BI=>this.info=BI)
  
  }

}
