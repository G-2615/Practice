import { Component, OnInit } from '@angular/core';
import { item } from './itemnew';
import{SearchService } from '../search.service'
@Component({
  selector: 'app-comp-item',
  templateUrl: './comp-item.component.html',
  styleUrls: ['./comp-item.component.css']
})
export class CompItemComponent implements OnInit {

  StringStr:String;
  items: item[];

  constructor(private dataService: SearchService ) { }

  ngOnInit() {
    this.StringStr = "";
  }

  private searchitem() {
    this.dataService.getitem(this.StringStr)
      .subscribe(Items => this.items = Items);
  }

  onSubmit() {
    this.searchitem();
  }
}
