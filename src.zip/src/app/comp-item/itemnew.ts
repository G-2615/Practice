export class item{
    i_Id:number;
    item_Name:String;
    item_Price:number;
    item_Desc:String;
    category:number;
    subCategory:number;
    remarks:string;
    seller_Id:number;
    stock_Number:number;







}