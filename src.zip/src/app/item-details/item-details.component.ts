import { Component, OnInit, Input } from '@angular/core';
import { Itemsearch1 } from '../Item';
import { cartitems } from '../cart';
import { SearchService} from '../newservice';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {

  cartitem: cartitems;


  constructor(private dataService : SearchService) { }
  
  @Input() items:Itemsearch1 = new Itemsearch1();
  ngOnInit(): void {
  }
  addtocart(){
    this.cartitem = new cartitems();
    this.cartitem.i_Id = this.items.i_Id;
    //this.cartitem.cartitem_Id=5;
    this.cartitem.item_price = this.items.item_Price;
    this.cartitem.quantity = 1;

    this.dataService.additems(this.cartitem).subscribe(cartitems=>this.cartitem=cartitems);


  }

}
