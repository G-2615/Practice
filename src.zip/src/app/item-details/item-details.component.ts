import { Component, OnInit, Input } from '@angular/core';
import { Itemsearch1 } from '../Item';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {

  constructor() { }
  
  @Input() items:Itemsearch1;
  ngOnInit(): void {
  }

}
