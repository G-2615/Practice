import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompSearchComponent } from './comp-search.component';

describe('CompSearchComponent', () => {
  let component: CompSearchComponent;
  let fixture: ComponentFixture<CompSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
