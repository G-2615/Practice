import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-search',
  templateUrl: './comp-search.component.html',
  styleUrls: ['./comp-search.component.css']
})
export class CompSearchComponent implements OnInit {
