export class searchitem{
    searchstr : string
}