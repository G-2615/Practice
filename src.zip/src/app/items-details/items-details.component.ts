import { Component, OnInit,Input } from '@angular/core';
import { itemnew} from '../comp-item';
import {SearchService} from '../search.service'

@Component({
  selector: 'app-items-details',
  templateUrl: './items-details.component.html',
  styleUrls: ['./items-details.component.css']
})
export class ItemsDetailsComponent implements OnInit {

  @Input() it: itemnew;

  constructor(private searchService: SearchService, private listComponent: CustomersListComponent) { }


  ngOnInit(): void {
  }

}
