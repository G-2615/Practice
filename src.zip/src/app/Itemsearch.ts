export class ItemList{
    itemname:String;
}