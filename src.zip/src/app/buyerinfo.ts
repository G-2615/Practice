export class infobuyer{
    
     buyer_Name:string;
	 buyer_Email:string;
     buyer_Mobile:number;
	 buyer_password:string;
	 buyer_add1:string;
	 buyer_add2:string;
}