import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable}  from 'rxjs';
import { Itemsearch1 } from './Item';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  private baseUrl = 'http://localhost:8083/search';
  constructor(private http:HttpClient) { }

  getitem(ItemSear: Object): Observable<any> {
    return this.http.post(`${this.baseUrl}`,ItemSear);
  }
}