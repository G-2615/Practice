export class Itemsearch1
{
    
    item_Name:String;
	item_Price:number;
	item_Desc:String;
    remarks:String;
  //  stock_Number:number;
   // category_Id:number;
   // subcat_Id:number;
    //seller_Id:number;
	
}

/*{   
    productName:String;
    manufacturer:String;
    model:String;
    price:number;
    quantity:number;
    description:String;
    picture:String;
    }*/