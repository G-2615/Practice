import { Injectable } from '@angular/core';
import {cartitems} from './cart';
import { HttpClient } from '@angular/common/http';
import {Observable}  from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class BuyerService {

  private baseUrl4 = 'http://localhost:8082/2/allitems';
  private baseUrl1 = 'http://localhost:8082/adduser';

  constructor(private http:HttpClient) { }


  getallItems():Observable<any>
  { 
    console.log("In Service");
    return this.http.get(`${this.baseUrl4}`);
  }

  buyersign(BI:object): Observable <any>
  
  {
      console.log("BI");
      console.log(BI);
      return this.http.post(`${this.baseUrl1}`,BI);
  }
}
