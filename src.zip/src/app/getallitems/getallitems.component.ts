import { Component, OnInit, Input } from '@angular/core';
import { cartitems } from '../cart';
import {BuyerService} from '../buyer.service';

@Component({
  selector: 'app-getallitems',
  templateUrl: './getallitems.component.html',
  styleUrls: ['./getallitems.component.css']
})
export class GetallitemsComponent implements OnInit {

  cartitemss:cartitems[];
  //cartitemsss:cartitems;
  show:boolean = false;
  constructor(private dataService : BuyerService ) { }
  @Input() cartitem = new cartitems();
  ngOnInit(): void {


  }

  getallcartitems(){
    this.show = true;
    this.dataService.getallItems().subscribe(cartitems=>this.cartitemss= cartitems);

  }

}
