import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import {SearchService} from './newservice';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { ItemDetailsComponent } from './item-details/item-details.component';
//import { SellerformComponent } from './sellerform/sellerform.component';
import { AdditemsComponent } from './additems/additems.component';
//import { SellerSignupComponent } from './seller-signup/seller-signup.component';
import { GetallitemsComponent } from './getallitems/getallitems.component';

@NgModule({
  declarations: [
    AppComponent,
    ItemDetailsComponent,
   // SellerformComponent,
    AdditemsComponent,
  // SellerSignupComponent,
   GetallitemsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [SearchService],
  bootstrap: [AppComponent]
})
export class AppModule { }
