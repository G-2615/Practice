export class searchOption {
    id: number;
    name: string;
    age: number;
    active: boolean;
}
