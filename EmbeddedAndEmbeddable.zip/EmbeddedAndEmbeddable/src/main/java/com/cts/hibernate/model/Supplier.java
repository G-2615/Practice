package com.cts.hibernate.model;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Supplier {
	@Id
	@GeneratedValue
	private int supplierID;
	@Embedded
	@AttributeOverride(column = @Column, name = "supplierName")
	private Name name;
	public Supplier() {
		// TODO Auto-generated constructor stub
	}
	public int getSupplierID() {
		return supplierID;
	}
	public void setSupplierID(int supplierID) {
		this.supplierID = supplierID;
	}
	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public Supplier( Name name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Supplier [supplierID=" + supplierID + ", name=" + name + "]";
	}
	
}
