package com.cts.hibernate.EmbeddedAndEmbeddable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Buyer;
import com.cts.hibernate.model.Name;
import com.cts.hibernate.model.Supplier;

public class App 
{
    public static void main( String[] args )
    {
        Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Name supplierName = new Name("Mr.","Ram", "Kumar");
        Name buyerName = new Name("Mr.","Ravi", "Sharma"); 
        Supplier supplier = new Supplier(supplierName);
        Buyer buyer =  new Buyer(buyerName);
        session.beginTransaction();
        session.save(supplier);
        session.save(buyer);
        session.getTransaction().commit();
        session.close();
    }
}
