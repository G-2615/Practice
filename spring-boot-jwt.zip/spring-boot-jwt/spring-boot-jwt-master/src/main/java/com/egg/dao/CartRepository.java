package com.egg.dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.egg.model.CartItems;



public interface CartRepository extends JpaRepository<CartItems, Integer> {

	 @Query(value = "SELECT * FROM cart_items WHERE user_buyer_Id = :buyer_Id", nativeQuery = true)
	
	 public List<CartItems> findAllBybuyer(@Param("buyer_Id")Integer buyer_Id);

	 
	 @Transactional
	 @Modifying
	 @Query(value="DELETE FROM cart_items WHERE cart_items.user_buyer_Id=:buyer_Id", nativeQuery = true)
	 public void emptyAll(@Param("buyer_Id") Integer buyer_Id);
	

}
