package com.egg.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.SellerRepository;
import com.egg.model.SellerInfo;
//import com.egg.model.UserInfo;

//import com.cts.seller.Repository.SellerRepository;
//import com.cts.seller.entities.SellerInfo;

@Service(value = "userService")
public class SellerServices implements UserDetailsService {
	
	@Autowired
	private SellerRepository sellerRepository;
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public SellerInfo addSeller(SellerInfo seller) {
		// TODO Auto-generated method stub
		seller.setSeller_Password(bcryptEncoder.encode(seller.getSeller_Password()));
		return sellerRepository.save(seller);
	}
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		SellerInfo user = sellerRepository.findByusername(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getSeller_Password(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

	public SellerInfo findOne(String username) {
		return sellerRepository.findByusername(username); 
	}

		
	}


 