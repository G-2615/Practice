package com.egg.model;

import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class Category {
	
	@Id
	
	private int category_Id;
	
	private String category_Name;
	
	private String brief_Details;

	public int getCategory_Id() {
		return category_Id;
	}

	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}

	public String getCategory_Name() {
		return category_Name;
	}

	public void setCategory_Name(String category_Name) {
		this.category_Name = category_Name;
	}

	public String getBrief_Details() {
		return brief_Details;
	}

	public void setBrief_Details(String brief_Details) {
		this.brief_Details = brief_Details;
	}

	public Category(int category_Id, String category_Name, String brief_Details) {
		super();
		this.category_Id = category_Id;
		this.category_Name = category_Name;
		this.brief_Details = brief_Details;
	}

	public Category() {
		super();
	}

	@Override
	public String toString() {
		return "Category [category_Id=" + category_Id + ", category_Name=" + category_Name + ", brief_Details="
				+ brief_Details + "]";
	}
	
	
	
	
	
	
	

	
}
