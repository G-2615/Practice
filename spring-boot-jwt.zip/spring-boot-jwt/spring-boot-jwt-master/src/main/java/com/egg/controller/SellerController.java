package com.egg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.SellerInfo;
import com.egg.service.SellerServices;

//import com.cts.seller.entities.SellerInfo;
//import com.cts.seller.services.SellerServices;

@RestController
public class SellerController {
	
	@Autowired
	private SellerServices sellerServices;
	
	
	@RequestMapping(value="/addSeller",method=RequestMethod.POST, produces="application/json")
	
	public SellerInfo add(@RequestBody SellerInfo seller) {
		
		SellerInfo sellerInfo = sellerServices.addSeller(seller);
				return sellerInfo;
				
				
		
	}
	

}
