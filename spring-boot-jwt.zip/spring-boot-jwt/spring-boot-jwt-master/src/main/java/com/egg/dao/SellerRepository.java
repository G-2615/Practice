package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egg.model.SellerInfo;

//import com.cts.seller.entities.SellerInfo;

@Repository
public interface SellerRepository extends JpaRepository<SellerInfo, Integer> {

	SellerInfo findByusername(String username);

	

}
