package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egg.model.User;
import com.egg.model.UserInfo;




@Repository
public interface BuyerRepository extends JpaRepository<UserInfo, Integer> {

	

	

	UserInfo findByusername(String username);

}
