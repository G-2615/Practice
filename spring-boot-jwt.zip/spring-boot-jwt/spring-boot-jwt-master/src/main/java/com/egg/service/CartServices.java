package com.egg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerRepository;
import com.egg.dao.CartRepository;
import com.egg.model.CartItems;


@Service
public class CartServices {
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;

	public Optional<CartItems> addtoCart(CartItems cartItems,Integer buyer_Id) {
		
		return buyerRepository.findById(buyer_Id).map(buyer -> {
            cartItems.setUser(buyer);
            return cartRepository.save(cartItems);
        });
				
		}

	public List<CartItems> getallCartItems(Integer buyer_Id) {
		// TODO Auto-generated method stub
		List<CartItems>getallItems=cartRepository.findAllBybuyer(buyer_Id);
		return getallItems;
	}
	
	public CartItems updateCart(CartItems cartItems, Integer cart_Id) {
		Optional<CartItems>cartItem= cartRepository.findById(cart_Id);
		//return cartRepository.save(cartItem);
		if(cartItem!=null) {
			CartItems cart=cartItem.get();
			cart.setQuantity(cartItems.getQuantity());
			return cartRepository.save(cart);
			
		}
		return null;
		
	
}

	public String  deleteID(Integer cart_Id) {
		// TODO Auto-generated method stub
		
		cartRepository.deleteById(cart_Id);
		return "DONE";
	}

	public String empty(Integer buyer_Id) {
		// TODO Auto-generated method stub
		cartRepository.emptyAll(buyer_Id);
		return null;
	}
}

