package com.egg.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class SubCategory {

	
	@Id
	private int subcat_Id;
	
	private String subcat_Name;
	
	@ManyToOne
	private Category category;
	
	private String subcat_Details; 
	
	private float gst;

	public int getSubcat_Id() {
		return subcat_Id;
	}

	public void setSubcat_Id(int subcat_Id) {
		this.subcat_Id = subcat_Id;
	}

	public String getSubcat_Name() {
		return subcat_Name;
	}

	public void setSubcat_Name(String subcat_Name) {
		this.subcat_Name = subcat_Name;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getSubcat_Details() {
		return subcat_Details;
	}

	public void setSubcat_Details(String subcat_Details) {
		this.subcat_Details = subcat_Details;
	}

	public float getGst() {
		return gst;
	}

	public void setGst(float gst) {
		this.gst = gst;
	}

	public SubCategory(int subcat_Id, String subcat_Name, Category category, String subcat_Details, float gst) {
		super();
		this.subcat_Id = subcat_Id;
		this.subcat_Name = subcat_Name;
		this.category = category;
		this.subcat_Details = subcat_Details;
		this.gst = gst;
	}

	public SubCategory() {
		super();
	}

	@Override
	public String toString() {
		return "SubCategory [subcat_Id=" + subcat_Id + ", subcat_Name=" + subcat_Name + ", category=" + category
				+ ", subcat_Details=" + subcat_Details + ", gst=" + gst + "]";
	}
	
	
		
	
}
