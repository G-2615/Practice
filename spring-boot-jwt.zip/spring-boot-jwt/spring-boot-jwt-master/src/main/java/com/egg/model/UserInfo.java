package com.egg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.Generated;

@Entity
public class UserInfo {
	
	@Id
	@GeneratedValue
	private int buyer_Id;
	private String username;
	private String buyer_Name;
	private String buyer_Email;
	private long buyer_Mobile;
	private String buyer_password;
	private String buyer_add1;
	private String buyer_add2;
	public int getBuyer_Id() {
		return buyer_Id;
	}
	public void setBuyer_Id(int buyer_Id) {
		this.buyer_Id = buyer_Id;
	}
	public String getBuyer_Name() {
		return buyer_Name;
	}
	public void setBuyer_Name(String buyer_Name) {
		this.buyer_Name = buyer_Name;
	}
	public String getBuyer_Email() {
		return buyer_Email;
	}
	public void setBuyer_Email(String buyer_Email) {
		this.buyer_Email = buyer_Email;
	}
	public long getBuyer_Mobile() {
		return buyer_Mobile;
	}
	public void setBuyer_Mobile(long buyer_Mobile) {
		this.buyer_Mobile = buyer_Mobile;
	}
	
	public String getBuyer_password() {
		return buyer_password;
	}
	public void setBuyer_password(String buyer_password) {
		this.buyer_password = buyer_password;
	}
	public String getBuyer_add1() {
		return buyer_add1;
	}
	public void setBuyer_add1(String buyer_add1) {
		this.buyer_add1 = buyer_add1;
	}
	public String getBuyer_add2() {
		return buyer_add2;
	}
	public void setBuyer_add2(String buyer_add2) {
		this.buyer_add2 = buyer_add2;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public UserInfo(int buyer_Id, String buyer_Name, String buyer_Email, long buyer_Mobile,String buyer_password ,String buyer_add1,
			String buyer_add2, String username ) {
		super();
		this.buyer_Id = buyer_Id;
		this.buyer_Name = buyer_Name;
		this.buyer_Email = buyer_Email;
		this.buyer_Mobile = buyer_Mobile;
		this.buyer_password=buyer_password;
		this.buyer_add1 = buyer_add1;
		this.buyer_add2 = buyer_add2;
		this.username = username;
	}
	public UserInfo() {
		super();
	}
	@Override
	public String toString() {
		return "UserInfo [buyer_Id=" + buyer_Id + ", username=" + username + ", buyer_Name=" + buyer_Name
				+ ", buyer_Email=" + buyer_Email + ", buyer_Mobile=" + buyer_Mobile + ", buyer_password="
				+ buyer_password + ", buyer_add1=" + buyer_add1 + ", buyer_add2=" + buyer_add2 + "]";
	}
	
	
	
	
	

}
